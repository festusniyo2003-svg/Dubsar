# DUBSAR Android project

This project wraps the first DUBSAR learning app in a native Android WebView shell. It keeps the existing English/Kirundi lessons and local learning data while providing an Android launcher app.

## Build an installable APK

### Easiest: GitHub Actions (no computer build tools needed on your phone)
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build DUBSAR APK** (or push to `main`).
4. Open the successful workflow run and download the `DUBSAR-debug-APK` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that browser/file manager.

### Build locally
Install Android Studio with Android SDK 35 and JDK 17, open this folder, then run `gradle assembleDebug`.

This is a debug APK for testing and direct installation, not a Play Store release. A signed release build and full device testing are still needed before publishing. Notes and progress are stored locally on the device and are not backed up to an account.
