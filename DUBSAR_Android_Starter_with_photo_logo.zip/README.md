# DUBSAR — The Filmmaking & Screenwriting Academy

A fresh Android starter project built with Kotlin and Jetpack Compose.

## Current first version
- Cinematic dark interface
- English language edition
- Home screen with 12 learning departments
- Department detail screens
- GitHub Actions workflow to build a debug APK

## Build an APK with GitHub
1. Create a new GitHub repository named `DUBSAR`.
2. Upload the contents of this project (not the enclosing folder).
3. Open the repository's **Actions** tab.
4. Select **Build DUBSAR APK** and choose **Run workflow**, or push to `main`.
5. When the workflow finishes, open the run and download the `DUBSAR-debug-APK` artifact.

This is a starter app, not yet the complete academy. Lesson content, quizzes, saved progress, and the writing workspace will be added in later stages.
