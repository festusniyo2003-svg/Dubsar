package com.dubsar.academy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF080D18)
private val Panel = Color(0xFF111B2D)
private val Blue = Color(0xFF398BFF)
private val Pale = Color(0xFFEAF2FF)
private val Muted = Color(0xFF9BAAC2)

data class Department(val number: String, val title: String, val subtitle: String)

private val departments = listOf(
    Department("01", "Story Development", "Build powerful story ideas"),
    Department("02", "Character Development", "Create unforgettable characters"),
    Department("03", "Screenwriting", "Turn ideas into screenplays"),
    Department("04", "Storytelling", "Master the art of narrative"),
    Department("05", "Film Directing", "Bring the script to life"),
    Department("06", "Cinematography", "Tell stories through images"),
    Department("07", "Film Production", "Plan and manage a film"),
    Department("08", "Film Editing", "Shape the final story"),
    Department("09", "Sound and Music", "Create the world of sound"),
    Department("10", "Acting and Performance", "Understand performance"),
    Department("11", "Film History and Analysis", "Learn from cinema"),
    Department("12", "Filmmaking Business", "Build a creative career")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DubsarApp() }
    }
}

@Composable
fun DubsarApp() {
    var selectedDepartment by remember { mutableStateOf<Department?>(null) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night,
            surface = Panel,
            primary = Blue,
            onBackground = Pale,
            onSurface = Pale
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            if (selectedDepartment == null) {
                HomeScreen(onDepartmentClick = { selectedDepartment = it })
            } else {
                DepartmentScreen(
                    department = selectedDepartment!!,
                    onBack = { selectedDepartment = null }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onDepartmentClick: (Department) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Night)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFF142A4A), Night)))
                .padding(horizontal = 22.dp, vertical = 28.dp)
        ) {
            Text("THE FILMMAKING & SCREENWRITING ACADEMY", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            Text("DUBSAR", color = Pale, fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("IMAGINE. LEARN. WRITE. DIRECT. CREATE.", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(22.dp))
            Text("Your filmmaking journey starts here.", color = Pale, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Learn the craft. Develop your voice. Create your stories.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Blue, RoundedCornerShape(50)))
                Spacer(Modifier.width(8.dp))
                Text("ENGLISH EDITION  •  BEGINNER TO CREATOR", color = Pale, fontSize = 9.sp, letterSpacing = 0.7.sp)
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("LEARNING DEPARTMENTS", color = Pale, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("12 SUBJECTS", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(departments) { department ->
                DepartmentCard(department, onClick = { onDepartmentClick(department) })
            }
        }
    }
}

@Composable
fun DepartmentCard(department: Department, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(142.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(department.number, color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Column {
            Text(department.title, color = Pale, fontSize = 14.sp, fontWeight = FontWeight.Bold, lineHeight = 18.sp)
            Spacer(Modifier.height(5.dp))
            Text(department.subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
fun DepartmentScreen(department: Department, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("‹  BACK TO ACADEMY", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable(onClick = onBack).padding(vertical = 12.dp))
        Spacer(Modifier.height(30.dp))
        Text("DEPARTMENT ${department.number}", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Text(department.title, color = Pale, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 36.sp)
        Spacer(Modifier.height(12.dp))
        Text(department.subtitle, color = Muted, fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("YOUR LESSONS", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(10.dp))
                Text("The curriculum for this department is being prepared.", color = Pale, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Each lesson will include detailed explanations, professional examples, practical exercises and a knowledge quiz.", color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("DUBSAR • IMAGINE. LEARN. CREATE.", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}
